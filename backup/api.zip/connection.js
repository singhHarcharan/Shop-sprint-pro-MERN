const mysql = require("mysql");

// DB Connection
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "system",
    database: "fullstack_clothe_store",
    port: 3308
});

connection.connect((error) => {
    if (error) {
        // console.log("Error");
        console.log(error.message);
    } else {
        console.log("Database Connected");
    }
});

module.exports = connection;
