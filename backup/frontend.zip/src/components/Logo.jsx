import {Link} from "react-router-dom";

const Logo = () => {
    return (
        <div className="col-xl-2 col-6">
            <div className="header-logo">
                <Link to="/">
                    <img src="/assets/images/logo/logo.png" width="" alt="Site Logo"/>
                </Link>
            </div>
        </div>
    )
}
export default Logo;